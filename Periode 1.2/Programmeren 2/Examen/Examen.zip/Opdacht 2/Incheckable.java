public interface Incheckable {
    public void checkin();
}
