import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Testing {

    public static void main(String[] args) {

        char[] charArray = {'A', 'B', 'C', 'D', 'E', 'F'};
        Flight flight = new Flight("T001", charArray, 15);

    }
}
