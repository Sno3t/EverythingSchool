public class Storage {

    public Flight readFlight(){
        char[] chars = new char[6];
        return new Flight("1",chars,3);
    }

    public void saveFlight(Flight flight){

    }
}
