enum PaneelType {
    KUNSTSTOFGLAS,
    GLASGLAS
}

