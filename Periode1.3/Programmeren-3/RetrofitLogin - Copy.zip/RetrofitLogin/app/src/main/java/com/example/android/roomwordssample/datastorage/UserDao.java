package com.example.android.roomwordssample.datastorage;

public interface UserDao {
    // ToDo alleen nodig als je de user in de database wilt opslaan

}
