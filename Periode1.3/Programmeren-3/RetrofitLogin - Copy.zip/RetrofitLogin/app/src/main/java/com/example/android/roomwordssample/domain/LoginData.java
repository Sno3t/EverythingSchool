package com.example.android.roomwordssample.domain;

public class LoginData {
    public String emailAdress;
    public String password;

    public LoginData(String emailAdress, String password) {
        this.emailAdress = emailAdress;
        this.password = password;
    }


}
